import React from 'react';
import CardMedia from '@material-ui/core/CardMedia';
import Avatar from '@material-ui/core/Avatar';
import "./style.css";
export default class Logo extends React.Component {
  render(){
    return (
      <div>
         <img className="Logo" src="/static/images/Logo.png" />


      </div>
    )
  }



}
